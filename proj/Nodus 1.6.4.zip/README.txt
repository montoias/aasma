Client: Nodus
Client by: Scetch
Client recoded & updated to MC_1.6.4 by: SirJava

+++++++ URL's +++++++
  Donate: http://j.mp/18GCEGf
  Update-URL: 

Y = GUI
U = Console

Client has OptiFine_1.6.4_HD_U_B1

+++++++ Install +++++++
 - Go to "%appdata%"
 - Open ".minecraft"
 - Open "versions"
 - Create a folder and call it "Nodus"
 - Extract the Nodus.zip
 - Put in the "Nodus.jar" and the "Nodus.json"
 - Start your Minecraft Launcher (the new launcher for > 1.6.*)
 - Click on "Edit Profile"
 - Click in "Use version: " on "release Nodus".
 - Click on "Save Profile".
 - Start Minecraft.
 - ENJOY :D & Happy Hacking